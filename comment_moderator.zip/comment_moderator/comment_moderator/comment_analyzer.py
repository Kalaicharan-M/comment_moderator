from transformers import pipeline
from better_profanity import profanity 

# Load the HuggingFace toxicity classifier
classifier = pipeline("text-classification", model="unitary/toxic-bert", top_k=None)

def classify_comment(comment):
    # Check for profanity first
    if profanity.contains_profanity(comment):
        pre_flagged = True
    else:
        pre_flagged = False

    try:
        result = classifier(comment)[0] 
        top_label = max(result, key=lambda x: x['score'])

        if top_label['label'] != 'non-toxic' and top_label['score'] > 0.6:
            is_offensive = True
            offense_type = top_label['label'].capitalize()
            explanation = f"Detected as '{top_label['label']}' with confidence {top_label['score']:.2f}"
        else:
            is_offensive = False
            offense_type = "None"
            explanation = "Comment is clean."

        # Add warning if profanity was flagged
        if pre_flagged and not is_offensive:
            explanation += " Contains mild profanity but not categorized as offensive by the model."

        return is_offensive, offense_type, explanation

    except Exception as e:
        print("Error:", e)
        return False, "Error", f"Error during classification: {str(e)}"
