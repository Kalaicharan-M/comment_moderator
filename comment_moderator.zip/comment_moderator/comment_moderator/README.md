# Comment Moderation Tool

This Python tool analyzes user comments to detect offensive content using Generative AI (OpenAI) and reports insights with visualizations.

## Features
- CSV/JSON input support
- GPT-based offense classification
- Profanity pre-filtering
- Report generation with summary and bar chart
- CLI support

## Setup

```bash
git clone https://github.com/your-repo/comment_moderator.git
cd comment_moderator
pip install -r requirements.txt
```

Add your OpenAI API key in a `.env` file:
```
OPENAI_API_KEY=your-api-key
```

## Usage

```bash
python main.py --file sample_data/comments.csv
```

## Output

- `output/flagged_comments.csv`: Processed comments
- `output/offense_distribution.png`: Offense type chart
