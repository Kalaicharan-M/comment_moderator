import argparse
import pandas as pd # type: ignore
from comment_analyzer import classify_comment
from utils import save_output, plot_offense_distribution

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--file', type=str, required=True, help='Path to the comments CSV file')
    args = parser.parse_args()

    df = pd.read_csv(args.file)
    print(f"Loaded {len(df)} comments.")
    print(df.head())

    print("Analyzing comments...\n")

    offensive_flags = []
    offense_types = []
    explanations = []

    for comment in df['comment_text']:
        is_offensive, offense_type, explanation = classify_comment(comment)
        offensive_flags.append(is_offensive)
        offense_types.append(offense_type)
        explanations.append(explanation)

    df['is_offensive'] = offensive_flags
    df['offense_type'] = offense_types
    df['explanation'] = explanations

    save_output(df)
    plot_offense_distribution(df)

if __name__ == "__main__":
    main()
