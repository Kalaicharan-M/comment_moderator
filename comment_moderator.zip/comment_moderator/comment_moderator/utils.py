import pandas as pd
import matplotlib.pyplot as plt
import os

def save_output(df, filename='output/analysis_result.csv'):
    os.makedirs('output', exist_ok=True)
    df.to_csv(filename, index=False)
    print(f"\nResults saved to {filename}")

def plot_offense_distribution(df):
    counts = df[df['is_offensive'] == True]['offense_type'].value_counts()
    if counts.empty:
        print("No offensive comments to plot.")
        return
    counts.plot(kind='bar', title='Offense Type Distribution')
    plt.xlabel("Offense Type")
    plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig("output/offense_distribution.png")
    plt.show()
